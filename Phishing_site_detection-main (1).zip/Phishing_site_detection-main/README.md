# Phishing_site_detecter
this project using machine learning algorithms detect if a given url belongs to a phishng site or not <br/> 

execution---> <br/>
python3 decision_tree.py <br/>
or <br/>
python3 naive_bayes.py <br/>
or <br/>
python3 k-nn.py
